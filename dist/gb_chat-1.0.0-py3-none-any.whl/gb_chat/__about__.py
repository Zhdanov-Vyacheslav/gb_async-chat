__all__ = [
    "__title__",
    "__summary__",
    "__version__",
    "__author__",
    "__email__"
]

__title__ = "gb-chat"
__summary__ = "Chat server and client for chating"
__version__ = "1.0.0"
__author__ = "Zhdanov Vyacheslav"
__email__ = "test@test.cc"
